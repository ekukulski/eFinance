namespace KukiFinance.Models;

public class CategoryMapping
{
    public string Description { get; set; }
    public string Category { get; set; }
}